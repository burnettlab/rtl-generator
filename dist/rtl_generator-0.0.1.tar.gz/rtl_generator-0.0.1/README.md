# RTL-Generator

This repository contains an RTL-Generator and flexible parameterizer written in Python. Documentation is ongoing, so check back here later to learn how to use this program.
